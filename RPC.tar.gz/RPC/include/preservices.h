#ifndef _MY_PRESERVICES_H_
#define _MY_PRESERVICES_H_

char* pre_sayHello(char *str);
char* pre_sum(char *str);
char* pre_sayGoodbye(char *str);

#endif
