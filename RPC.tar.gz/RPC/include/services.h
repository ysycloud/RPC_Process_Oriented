#ifndef _MY_SERVICES_H_
#define _MY_SERVICES_H_

#define FUNC_MAX 50
#define PARAM_LEN 50
#define PARAM_MAX 20
#define SEND_MAX 500
#define RETURN_MAX 500

char* sayHello(char myName[], int myAge);
int sum( int item1, int item2);
char* sayGoodbye(char myName[]);

#endif
